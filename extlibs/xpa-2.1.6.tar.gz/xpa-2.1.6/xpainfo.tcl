proc XPAInfo args {
  global xpa
  if { ([info exists xpa] && ($xpa != "")) } {
    puts [format "XPA_VERSION:\t%s" [xparec $xpa version]]
    puts [format "XPA_CLASS:\t%s"   [xparec $xpa class]]
    puts [format "XPA_NAME:\t%s"    [xparec $xpa name]]
    puts [format "XPA_METHOD:\t%s"  [xparec $xpa method]]
  } else {
    puts [format "XPA not initialized"]
  }
}

XPAInfo
