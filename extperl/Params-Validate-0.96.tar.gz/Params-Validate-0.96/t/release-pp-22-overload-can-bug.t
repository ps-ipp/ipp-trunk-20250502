

use Test::More;

BEGIN {
    unless ( $ENV{RELEASE_TESTING} ) {
        plan skip_all => 'these tests are for testing by the release';
    }

    $ENV{PERL_TEST_PV} = 1;
}

use strict;
use warnings;

use Params::Validate qw(validate);
use Test::More;

{

    package Overloaded;

    use overload 'bool' => sub {0};

    sub new { bless {} }

    sub foo {1}
}

my $ovl = Overloaded->new;

{
    eval {
        my @p = ( object => $ovl );
        validate( @p, { object => { isa => 'Overloaded' } } );
    };

    is( $@, q{}, 'overloaded object->isa' );
}

{
    eval {
        my @p = ( object => $ovl );
        validate( @p, { object => { can => 'foo' } } );
    };

    is( $@, q{}, 'overloaded object->foo' );
}

done_testing();

